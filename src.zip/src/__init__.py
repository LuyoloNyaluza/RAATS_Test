# RGR Calculator Module
